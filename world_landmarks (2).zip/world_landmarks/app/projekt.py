
def calculate_bmr(weight, height, age, gender):
    if gender == "м":
        return 10 * weight + 6.25 * height - 5 * age + 5
    elif gender == "ж":
        return 10 * weight + 6.25 * height - 5 * age - 161
    else:
        return 10 * weight + 6.25 * height - 5 * age + 5

def adjust_calories(bmr, goal):
    if goal == "похудеть":
        return bmr * 0.85
    elif goal == "набрать":
        return bmr * 1.15
    elif goal == "поддерживать":
        return bmr
    else:
        return bmr

def calculate_macros(calories):
    protein = (calories * 0.3) / 4
    fat = (calories * 0.25) / 9
    carbs = (calories * 0.45) / 4
    return round(protein), round(fat), round(carbs)

def get_workout_plan(goal):
    if goal == "похудеть":
        